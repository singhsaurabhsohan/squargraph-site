# Fonts

Place these 3 files here (download from fontshare.com/fonts/satoshi):

- Satoshi-Regular.woff2
- Satoshi-Medium.woff2
- Satoshi-Bold.woff2

Delete this README after adding the files.
