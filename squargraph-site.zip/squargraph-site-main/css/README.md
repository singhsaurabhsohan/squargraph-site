# CSS

Place this file here:

- intlTelInput.css

Download from:
https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.21/css/intlTelInput.min.css
Rename it to intlTelInput.css after saving.

Delete this README after adding the file.
